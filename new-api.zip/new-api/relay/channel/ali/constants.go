package ali

var ModelList = []string{
	"qwen-turbo", "qwen-plus", "qwen-max", "qwen-max-longcontext",
	"text-embedding-v1",
}

var ChannelName = "ali"
