package jina

var ModelList = []string{
	"jina-clip-v1",
	"jina-reranker-v2-base-multilingual",
}

var ChannelName = "jina"
