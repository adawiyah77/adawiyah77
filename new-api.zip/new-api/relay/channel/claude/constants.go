package claude

var ModelList = []string{
	"claude-instant-1.2",
	"claude-2",
	"claude-2.0",
	"claude-2.1",
	"claude-3-sonnet-20240229",
	"claude-3-opus-20240229",
	"claude-3-haiku-20240307",
	"claude-3-5-sonnet-20240620",
}

var ChannelName = "claude"
