package zhipu_4v

var ModelList = []string{
	"glm-4", "glm-4v", "glm-3-turbo", "glm-4-alltools",
}

var ChannelName = "zhipu_4v"
