package cohere

var ModelList = []string{
	"command-r", "command-r-plus", "command-light", "command-light-nightly", "command", "command-nightly",
	"rerank-english-v3.0", "rerank-multilingual-v3.0", "rerank-english-v2.0", "rerank-multilingual-v2.0",
}

var ChannelName = "cohere"
