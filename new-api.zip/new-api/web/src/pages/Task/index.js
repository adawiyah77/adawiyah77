import React from 'react';
import TaskLogsTable from "../../components/TaskLogsTable.js";

const Task = () => (
  <>
    <TaskLogsTable />
  </>
);

export default Task;
