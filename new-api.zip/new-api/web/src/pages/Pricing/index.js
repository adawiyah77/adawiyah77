import React from 'react';
import ModelPricing from '../../components/ModelPricing.js';

const Pricing = () => (
  <>
    <ModelPricing />
  </>
);

export default Pricing;
