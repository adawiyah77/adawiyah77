export const ITEMS_PER_PAGE = 10; // this value must keep same as the one defined in backend!
